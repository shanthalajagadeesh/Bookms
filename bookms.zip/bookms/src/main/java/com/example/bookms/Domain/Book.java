package com.example.bookms.Domain;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Optional;

import static org.springframework.http.ResponseEntity.ok;

@Entity
@Table(name = "books_data")
public class Book {

    @Id
    private String isbn; //isbn as primary key
    private String title;
    private String publishDate;
    private Integer totalCopies;
    private Integer issuedCopies;
    private String author;

    // No-argument constructor required by JPA
    public Book() {}

    // Parameterized constructor for convenience
    public Book(String isbn, String title, String publishDate, Integer totalCopies, Integer issuedCopies, String author) {
        this.isbn = isbn;
        this.title = title;
        this.publishDate = publishDate;
        this.totalCopies = totalCopies;
        this.issuedCopies = issuedCopies;
        this.author = author;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    public String getIsbn() {
        return isbn;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getTitle(){
        return title;
    }
    public String getPublishDate() {
        return publishDate;
    }
    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }
    public void setIssuedCopies(Integer issuedCopies) {
        this.issuedCopies = issuedCopies;
    }
    public Integer getIssuedCopies() {
        return issuedCopies;
    }
    public Integer getTotalCopies() {
        return totalCopies;
    }
    public void setTotalCopies(Integer totalCopies) {
        this.totalCopies = totalCopies;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public String getAuthor() {
        return author;
    }
}
