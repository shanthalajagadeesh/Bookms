package com.example.bookms.api;

import com.example.bookms.Domain.Book;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.bookms.repo.BookRepo;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import static org.springframework.http.ResponseEntity.*;
import static org.springframework.http.ResponseEntity.notFound;

@RestController
@RequestMapping("/api/books")
public class BookResource {
    private static final Logger LOGGER = LoggerFactory.getLogger(BookResource.class);

    @Autowired
    private BookRepo bookrepo; // Dependency Injection
    @GetMapping("/books")
    public List<Book> getAllbooks() {
        LOGGER.info("Getting all books from database");
        return bookrepo.findAll();
    }

    @GetMapping("/books/{isbn}")
    public ResponseEntity<Book> getBookByIsbn(@PathVariable Long isbn) {
        LOGGER.info("Getting single book with isbn {} from database", isbn);
        Optional<Book> bookFound = bookrepo.findById(isbn);
        if (bookFound.isPresent()) {
            LOGGER.info("bookFound with id {} from database", isbn);
            return ok(bookFound.get()); // returns http status code of 200
        }
        LOGGER.error("book NOT Found with isbn {} from database", isbn);
        return notFound().build(); // returns http status code of 404
    }
    @PostMapping("/books")
    public ResponseEntity<Book> addbook(@RequestBody Book book) {
        LOGGER.info("Saving book into database");
        Book savedbook = bookrepo.save(book);
        LOGGER.info("book saved into database with id generated as {}", savedbook.getIsbn());
        return created(URI.create(savedbook.getIsbn().toString())).body(savedbook);// returns http status code of 201
    }
    @DeleteMapping("/book/{isbn}")
    public ResponseEntity<Book> deleteBookByIsbn(@PathVariable Long isbn) {
        LOGGER.info("deleting single book with isbn {} from database", isbn);
        Optional<Book> bookFound = bookrepo.findById(isbn);
        if (bookFound.isPresent()) {
            bookrepo.delete(bookFound.get());
            LOGGER.info("book deleted with isbn {} from database", isbn);
            return ok(bookFound.get()); // returns http status code of 200
        }else  {
            LOGGER.warn("book with isbn {} not found in database", isbn);
            return notFound().build(); // returns http status code of 404
        }
    }

    @PutMapping("/book/{isbn}")
    public ResponseEntity<Book> updateBookByIsbn(@RequestBody Book book,@PathVariable Long isbn) {
        LOGGER.info("update book with isbn {} from database", isbn);
        Optional<Book> updating = bookrepo.findById(isbn);
        if (updating.isPresent()) {
            book.setIsbn(Long.valueOf(isbn));
            Book savedbook = bookrepo.save(book);
            LOGGER.info("book updated with isbn {} from database", isbn);
            return ResponseEntity.ok(savedbook);// returns http status code of 200
        }else  {
            LOGGER.warn("book with isbn {} not found in database", isbn);
            return notFound().build(); // returns http status code of 404
        }
    }

}
