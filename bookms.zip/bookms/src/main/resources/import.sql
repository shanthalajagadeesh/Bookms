insert into books_data values ('100001', 'John Dane',0,'20-01-2020','Johns Miracle',10);
insert into books_data values ('100002', 'Rhonda Byrne',0,'20-01-2022','Secret',10);
